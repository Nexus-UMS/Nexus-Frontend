import React from 'react'

export default function RegSuccess() {
  return (
    <div>
        <h1>Registration Successfully</h1>
    </div>
  )
}
