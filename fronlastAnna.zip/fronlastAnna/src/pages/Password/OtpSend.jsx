import React from 'react'

export default function OtpSend() {
  return (
    <div>
        <div>
            <table>
                <tbody>
                    <tr>
                        <td>Username:</td>
                        <td>
                            <input type='text'/>
                        </td>
                    </tr>
                    <tr>
                        <td>Email:</td>
                        <td>
                            <input type='email'/>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
  )
}
