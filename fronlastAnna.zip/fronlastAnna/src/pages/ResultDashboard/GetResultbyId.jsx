import axios from 'axios'
import React, { useState } from 'react'

export default function GetResultbyId() {
    const [id, setId] = useState("")
    const [res,setRes]= useState({})
    function GetData(){
        axios
        .get("http://localhost:5099/api/Result/GetResultById/"+id)
        .then((response)=>{
            console.log(response.data);
            setRes(response.data)
        })
    }
  return (
    <div>
        <table>
        <tr>
            <td>Result Id:</td>
            <input type='text' value={id} onChange={(e)=>setId(e.target.value)}/>
        </tr>
        <tr>
            <td rowSpan={2}>
                <button onClick={GetData}>Get Result</button>
            </td>
        </tr>
        </table>
        <table>
            <thead>
                <tr>
                    <th>Result Id</th>
                    <th>Exam Id</th>
                    <th>Student Id</th>
                    <th>Subject Id</th>
                    <th>Mark</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{res.resultId}</td>
                    <td>{res.examId}</td>
                    <td>{res.studentId}</td>
                    <td>{res.subjectId}</td>
                    <td>{res.marks}</td>
                </tr>
            </tbody>
        </table>
    </div>
  )
}
