import axios from 'axios'
import React, { useState } from 'react'

export default function UpdateResult() {
  const [id, setId] = useState("")
  const [mark, setMark] = useState("")
  const [getmark, setGetmark] = useState({})



  function Update(){
    axios
    .get("http://localhost:5099/api/Result/GetResultById/"+id)
    .then((response)=>{
      setGetmark(response.data)
    })
    .catch((err)=>console.log(err))

    let res={
      resultId: getmark.resultId,
      examId: getmark.examId,
      studentId: getmark.studentId,
      subjectId: getmark.subjectId,
      marks: mark
    }
    console.log(res);
    axios.put("http://localhost:5099/api/Result/UpdateStudent",res)
    .then((response)=>{
      alert("Updated Successfully")
    })
  }
    
  return (
    <div>
      <table>
        <tr>
          <td>Result Id:</td>
          <td>
            <input type='text' value={id} onChange={(e)=>setId(e.target.value)}/>
          </td>
        </tr>
        <tr>
          <td>Mark:</td>
          <td>
            <input type='text' value={mark} onChange={(e)=>setMark(e.target.value)}/>
          </td>
        </tr>
        <tr>
          <td rowSpan={2}>
            <button onClick={Update}>Edit</button>
          </td>
        </tr>
      </table>
    </div>
  )
}
