import React from 'react'
import AddResult from './AddResult'
import ViewResult from './ViewResult'
import DeleteResult from './DeleteResult'
import UpdateResult from './UpdateResult'
import GetResultbyId from './GetResultbyId'

export default function ResultDashboard() {
  return (
    <div>
        {/* <AddResult/> */}
        {/* <ViewResult/> */}
        {/* <DeleteResult/> */}
        {/* <UpdateResult/> */}
        <GetResultbyId/>
    </div>
  )
}
