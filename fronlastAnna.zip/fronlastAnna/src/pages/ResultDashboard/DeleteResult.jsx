
import axios from 'axios'
import React, { useState } from 'react'

export default function DeleteResult() {
    const[resultId,setResultId]=useState("")
    const[result,setResult]=useState({})
    function Delete(){
        axios
        .delete("http://localhost:5099/api/Result/DeleteStudentById/"+resultId)
        .then((response)=>{
            console.log(response.data);
            setResult(response.data);
            alert("Successfully Deleted");
        })
        .catch((error)=>{
            console.log(error);
        });
    }

  return (
    <div><label for="resultId">ResultID : </label>
    <input type="text" id='resultId' placeholder='enter the resultid' value={resultId} onChange={(e)=>setResultId(e.target.value)} />
    <button onClick={Delete}>Delete</button>
    </div>
  )
}

