import axios from 'axios';
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

export default function ViewResult() {
  const [mark, getMark] = useState([])
        const navigate=useNavigate();
 
        function GetAllResult() {
            if (sessionStorage.getItem("token") != null) {
                console.log(sessionStorage.getItem("token"));
                const header = {
                  Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                };
 
            axios
        .get("http://localhost:5099/api/Result/GetAllResult",{header})
        .then((response)=>{
            console.log(response.data);
            getMark(response.data);
        })
        .catch((error)=>{
            console.log(error);
        });
    }
   
    else{
        navigate('/login')
    }
  }
  return (
    <div className='container'>
       <button onClick={GetAllResult}>ViewAllResult</button>
      <table className='table table-stripped'>
        <thead>
        <tr>
          <th>resultId</th>
          <th>examId</th>
          <th>studentId</th>
          <th>subjectId</th>
          <th>marks</th>
        </tr>
        </thead>         
          <tbody>
                 {
                   mark.map((item)=>{
                        return(
                            <tr key={item.resultId}>
                               <td>{item.resultId}</td>
                                <td>{item.examId}</td>
                                <td>{item.studentId}</td>
                                <td>{item.subjectId}</td>
                                <td>{item.marks}</td>
                            </tr>  
                            )
                        })
                    }
            </tbody>
        
       
      </table>
    </div>
  )
}
