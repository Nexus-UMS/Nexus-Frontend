import React from 'react'
import StudentProfile from './StudentProfile'

export default function StudentDashboard() {
  return (
    <div>
      <StudentProfile/>
      </div>
  )
}
