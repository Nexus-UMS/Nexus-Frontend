import axios from 'axios';
import React, { useState } from 'react'

export default function GetTeacherBySection() {
    const [tsect, setTsect] = useState("")
    const [teachers, setTeachersSection] = useState([])

    function getbySect(){
      axios
      .get("http://localhost:5099/api/Teacher/TeacherbySection/"+tsect)
      .then((response)=>{
        console.log(response.data);
        setTeachersSection(response.data);
      })
      .catch((error)=>{
        console.log(error);
      });
    };
  return (
    <div>
         <div>
        <label for='Tsect'>Teacher Section: </label>
        <input type="text" id="Tsect" value={tsect} onChange={(e)=>setTsect(e.target.value)}/>
        <button onClick={getbySect}>SearchTeachersbySection</button>
         
<div className='container'>
            
            <table className='table table-stripped'>
                <thead>
                   <tr>
                        <th>Teacher Id</th>
                        <th>Firstname</th>
                        <th>Lastname</th>
                        <th>DOB</th>
                        <th>Gender</th>
                        <th>Subject Taught</th>
                        <th>Email</th>
                        <th>Class</th>
                        <th>Section</th>
                    
                  </tr>
               </thead>
               <tbody>
                    {
                      teachers.map((item)=>{
                           return(
                               <tr key={item.teacherid}>
                                    <td>{item.teacherid}</td>
                                   <td>{item.teacherFirstName}</td>
                                   <td>{item.teacherLastName}</td>
                                   <td>{item.dateOfBirth}</td>
                                   <td>{item.teacherGender}</td>
                                   <td>{item.teacherSubjectTaught}</td>
                                   <td>{item.teacherEmail}</td>
                                   <td>{item.teacherClass}</td>
                                   <td>{item.section}</td>
                                   </tr>  
                               )
                           })
                       }
               </tbody>
           </table>
          </div> 
    </div>
    </div>
  )
}


