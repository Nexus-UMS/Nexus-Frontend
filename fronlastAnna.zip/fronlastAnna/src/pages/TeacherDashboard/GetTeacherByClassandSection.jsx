import axios from 'axios';
import React, { useState } from 'react'

export default function GetTeacherByClassandSection() {
    const [tclss, setTclss] = useState("")
    const [tsect, setTsect] = useState("")
    const [teachers, setTeachers] = useState([])

    function getbyClassandSection(){
      axios
      .get("http://localhost:5099/api/Teacher/TeacherbyClassandSection/"+tclss+"/"+tsect)
      .then((response)=>{
        console.log(response.data);
        setTeachers(response.data);
      })
      .catch((error)=>{
        console.log(error);
      });
    };
  return (
    <div>
        <table>
            <tr>
                <td>
                Teacher Class:
                </td>
                <td>
                <input type="text" id="Tcls" value={tclss} onChange={(e)=>setTclss(e.target.value)}/>
                </td>
            </tr>
            <tr>
                <td>
                Teacher Section:
                </td>
                <td>
                <input type="text" id="Tsect" value={tsect} onChange={(e)=>setTsect(e.target.value)}/>
                </td>
            </tr>
            <tr>
                <td>
                <button onClick={getbyClassandSection}>SearchTeachersbyClassandSection</button>
                </td>
            </tr>
        </table>
     
<div className='container'>
        
        <table className='table table-stripped'>
            <thead>
               <tr>
                    <th>Teacher Id</th>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>DOB</th>
                    <th>Gender</th>
                    <th>Subject Taught</th>
                    <th>Email</th>
                    <th>Class</th>
                    <th>Section</th>
                
              </tr>
           </thead>
           <tbody>
                {
                  teachers.map((item)=>{
                       return(
                           <tr key={item.teacherid}>
                                <td>{item.teacherid}</td>
                               <td>{item.teacherFirstName}</td>
                               <td>{item.teacherLastName}</td>
                               <td>{item.dateOfBirth}</td>
                               <td>{item.teacherGender}</td>
                               <td>{item.teacherSubjectTaught}</td>
                               <td>{item.teacherEmail}</td>
                               <td>{item.teacherClass}</td>
                               <td>{item.section}</td>
                               </tr>  
                           )
                       })
                   }
           </tbody>
       </table>
      </div> 
</div>
  )
}
