import React from 'react'
import Profile from './Profile'
import EditProfile from './EditProfile'
import DeleteProfile from './DeleteProfile'
import GetAllTeachers from './GetAllTeachers'
import GetTeacherById from './GetTeacherById'
import GetTeacherByClass from './GetTeacherByClass'
import GetTeacherBySection from './GetTeacherBySection'
import GetTeacherByClassandSection from './GetTeacherByClassandSection'

export default function TeacherDashboard() {
  return (
    <div>
        {/* <Profile/> */}
        {/* <EditProfile/> */}
        {/* <DeleteProfile/> */}
        {/* <GetAllTeachers/> */}
        {/* <GetTeacherById/> */}
        {/* <GetTeacherByClass/> */}
        {/* <GetTeacherBySection/> */}
        <GetTeacherByClassandSection/>
    </div>
  )
}
