import axios from 'axios';
import React, { useState } from 'react'

export default function GetTeacherByClass() {
    const [tclss, setTclss] = useState("")
    const [teachers, setTeachersClass] = useState([])

    function getbyClass(){
      axios
      .get("http://localhost:5099/api/Teacher/TeacherbyClass/"+tclss)
      .then((response)=>{
        console.log(response.data);
        setTeachersClass(response.data);
      })
      .catch((error)=>{
        console.log(error);
      });
    };
    
  return (
    <div>
        <label for='Tcls'>Teacher Class: </label>
        <input type="text" id="Tcls" value={tclss} onChange={(e)=>setTclss(e.target.value)}/>
        <button onClick={getbyClass}>SearchTeachersbyClass</button>
         
<div className='container'>
            
            <table className='table table-stripped'>
                <thead>
                   <tr>
                        <th>Teacher Id</th>
                        <th>Firstname</th>
                        <th>Lastname</th>
                        <th>DOB</th>
                        <th>Gender</th>
                        <th>Subject Taught</th>
                        <th>Email</th>
                        <th>Class</th>
                    
                  </tr>
               </thead>
               <tbody>
                    {
                      teachers.map((item)=>{
                           return(
                               <tr key={item.teacherid}>
                                    <td>{item.teacherid}</td>
                                   <td>{item.teacherFirstName}</td>
                                   <td>{item.teacherLastName}</td>
                                   <td>{item.dateOfBirth}</td>
                                   <td>{item.teacherGender}</td>
                                   <td>{item.teacherSubjectTaught}</td>
                                   <td>{item.teacherEmail}</td>
                                   <td>{item.teacherClass}</td>
                                   </tr>  
                               )
                           })
                       }
               </tbody>
           </table>
          </div> 
    </div>
  )
}
