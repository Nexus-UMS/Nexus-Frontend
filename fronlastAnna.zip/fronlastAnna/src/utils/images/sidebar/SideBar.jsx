import React from 'react'
import "./SideBar.css"

export default function SideBar() {
  return (
    <div>

    <div className='side'>
aa
    </div>
    </div>
  )
}
